import { DebugContext } from './types';
export declare function initServicesIfNeeded(): void;
export declare function getCurrentDebugContext(): DebugContext;
